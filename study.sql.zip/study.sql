-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- 호스트: localhost
-- 처리한 시간: 14-08-25 21:26 
-- 서버 버전: 5.1.41
-- PHP 버전: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `study`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `evaluate`
--

CREATE TABLE IF NOT EXISTS `evaluate` (
  `IDevaluate` int(11) NOT NULL AUTO_INCREMENT,
  `evaluateName` text COLLATE utf8_unicode_ci NOT NULL,
  `picPath1` text COLLATE utf8_unicode_ci NOT NULL,
  `picPath2` text COLLATE utf8_unicode_ci NOT NULL,
  `picPath3` text COLLATE utf8_unicode_ci NOT NULL,
  `picPath4` text COLLATE utf8_unicode_ci NOT NULL,
  `picPath5` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IDevaluate`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- 테이블의 덤프 데이터 `evaluate`
--

INSERT INTO `evaluate` (`IDevaluate`, `evaluateName`, `picPath1`, `picPath2`, `picPath3`, `picPath4`, `picPath5`) VALUES
(1, '게임실력', '1', '2', '3', '4', '5'),
(2, '몇차원', '1', '2', '3', '4', '5');

-- --------------------------------------------------------

--
-- 테이블 구조 `friend`
--

CREATE TABLE IF NOT EXISTS `friend` (
  `IDfriend` int(11) NOT NULL AUTO_INCREMENT,
  `userID1` int(11) NOT NULL,
  `name1` text COLLATE utf8_unicode_ci NOT NULL,
  `userID2` int(11) NOT NULL,
  `name2` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IDfriend`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- 테이블의 덤프 데이터 `friend`
--

INSERT INTO `friend` (`IDfriend`, `userID1`, `name1`, `userID2`, `name2`) VALUES
(1, 1, '최지환', 2, '가상인물'),
(2, 1, '최지환', 3, '김용현'),
(3, 1, '최지환', 4, '이규진'),
(4, 3, '김용현', 4, '이규진');

-- --------------------------------------------------------

--
-- 테이블 구조 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `IDuser` int(11) NOT NULL AUTO_INCREMENT,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `gender` text COLLATE utf8_unicode_ci NOT NULL,
  `dateofbirth` date NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `registerDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `viewCnt` int(11) NOT NULL,
  `picPath` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IDuser`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- 테이블의 덤프 데이터 `user`
--

INSERT INTO `user` (`IDuser`, `username`, `password`, `gender`, `dateofbirth`, `name`, `registerDate`, `viewCnt`, `picPath`) VALUES
(1, '1', '1', 'm', '1990-02-25', '최지환', '0000-00-00 00:00:00', 0, ''),
(2, '2', '2', 'ㄹ', '1994-08-14', '가상인물', '0000-00-00 00:00:00', 0, ''),
(3, '3', '3', 'm', '0000-00-00', '김용현', '2014-08-25 20:08:16', 0, ''),
(4, '4', '4', 'm', '0000-00-00', '이규진', '2014-08-25 20:08:16', 0, '');

-- --------------------------------------------------------

--
-- 테이블 구조 `userevaluate`
--

CREATE TABLE IF NOT EXISTS `userevaluate` (
  `IDuserEvaluate` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `evaluateID` int(11) NOT NULL,
  `evaluateName` text COLLATE utf8_unicode_ci NOT NULL,
  `view` tinyint(1) NOT NULL,
  `sum` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`IDuserEvaluate`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=55 ;

--
-- 테이블의 덤프 데이터 `userevaluate`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `useruserevaluate`
--

CREATE TABLE IF NOT EXISTS `useruserevaluate` (
  `IDuserUserEvaluate` int(11) NOT NULL AUTO_INCREMENT,
  `userID1` int(11) NOT NULL,
  `userID2` int(11) NOT NULL,
  `evaluateID` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`IDuserUserEvaluate`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=92 ;

--
-- 테이블의 덤프 데이터 `useruserevaluate`
--

